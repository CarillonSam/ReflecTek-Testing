"""
Interactive stage calibration. Walks through the same nudge-to-corner protocol as the
original calibration routine: set an origin, then nudge to the far Y corner and far X
corner, computing scale/skew coefficients from how far off "ideal" those corners were.

Saves the result to StageConfig.calibration_file, so run_scan.py picks it up
automatically on future runs via GrblXY.calibration — no need to recalibrate every time.

Run this directly: python calibrate_stage.py
Re-run it any time the stage, mount, or board is physically disturbed.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import simpledialog

from config import ScanGeometryConfig, StageConfig
from stage import GrblXY, HexGridPlanner, StageCalibration


def _adjust(stage: GrblXY, target_x_mm: float, target_y_mm: float, parent=None) -> tuple[float, float]:
    """Moves to target, then lets the user nudge (x_err,y_err) until they accept (blank input)."""
    stage.goto_xy(target_x_mm, target_y_mm)
    stage.wait_until_reached(target_x_mm, target_y_mm)

    nudge_x = nudge_y = 0.0
    x_err = y_err = 1.0
    while abs(x_err) > 0.1 or abs(y_err) > 0.1:
        answer = simpledialog.askstring(
            "Stage calibration",
            f"Nudge for target ({target_x_mm:.2f}, {target_y_mm:.2f}) as 'x_err,y_err', blank to accept:",
            parent=parent,
        )
        if not answer:
            break
        x_err, y_err = map(float, answer.split(","))
        nudge_x += x_err
        nudge_y += y_err
        stage.goto_xy(target_x_mm + nudge_x, target_y_mm + nudge_y)
        stage.wait_until_reached(target_x_mm + nudge_x, target_y_mm + nudge_y)

    pos = stage.get_pos()
    return pos.x_mm, pos.y_mm


def calibrate(stage: GrblXY, x_span_mm: float, y_span_mm: float, parent=None) -> StageCalibration:
    """
    x_span_mm / y_span_mm: the ideal distance from origin to the far X / Y corner.
    parent: an existing Tk widget to host the dialogs under — pass this (e.g. the GUI's
    own root) when calling from within an already-running Tk app, so this doesn't create
    a second, conflicting Tk() root. Omit only when there's no Tk app running yet (the
    standalone __main__ block below), in which case a throwaway hidden root is created
    just so the dialogs have something to attach to.
    """
    owns_root = parent is None
    root = None
    if owns_root:
        root = tk.Tk()
        root.withdraw()
        parent = root
    try:
        stage.home_xy()
        stage.set_software_zero_here()
        _adjust(stage, 0.0, 0.0, parent)
        stage.set_software_zero_here()  # re-zero on the user-nudged true origin

        actual_y_corner = _adjust(stage, 0.0, y_span_mm, parent)
        actual_x_corner = _adjust(stage, x_span_mm, 0.0, parent)
    finally:
        if owns_root:
            root.destroy()

    return StageCalibration(
        scale_y=actual_y_corner[1] / y_span_mm,
        skew_x=actual_y_corner[0] / y_span_mm,
        scale_x=actual_x_corner[0] / x_span_mm,
        skew_y=actual_x_corner[1] / x_span_mm,
    )


if __name__ == "__main__":
    # Edit to match your setup — geometry only needs to be accurate enough to pick
    # sensible far corners to nudge to, it doesn't have to be the exact run geometry.
    stage_config = StageConfig(port="COM10", calibration_file="stage_calibration.json")
    geometry = ScanGeometryConfig(rows=16, cols=6, spacing_mm=12.03)

    planner = HexGridPlanner(geometry)
    # Signed, not just magnitude: HexGridPlanner multiplies by these same signs when
    # computing a real scan point's ideal coordinates, so the calibration needs to probe
    # the same signed extreme or it ends up calibrating the mirror-image corner instead
    # of the one a real scan will actually ask for.
    x_span_mm = geometry.x_direction_sign * (geometry.cols - 1) * geometry.spacing_mm
    y_span_mm = geometry.y_direction_sign * (geometry.rows - 1) * planner.row_spacing_mm

    stage = GrblXY(stage_config)
    try:
        calibration = calibrate(stage, x_span_mm, y_span_mm)
        calibration.save(stage_config.calibration_file)
        print("Saved calibration to", stage_config.calibration_file, "->", calibration.to_dict())
    finally:
        stage.goto_xy(0.0, 0.0)
        stage.close()

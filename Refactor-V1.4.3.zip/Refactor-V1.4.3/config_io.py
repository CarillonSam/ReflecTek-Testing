"""Convert RunConfig to/from plain JSON-safe dicts, for saving/loading GUI presets."""

from __future__ import annotations

import json
from dataclasses import fields
from pathlib import Path

from config import (
    PiControllerConfig, PixelControllerConfig, RunConfig, SaveConfig,
    ScanGeometryConfig, StageConfig, VNAConfig,
)

# Fields that are Path (or Path | None) and need str(...)/Path(...) conversion for JSON.
_PATH_FIELDS = {
    StageConfig: {"calibration_file"},
    PixelControllerConfig: {"mapping_csv"},
    SaveConfig: {"output_dir"},
}


def _sub_to_dict(obj) -> dict:
    path_fields = _PATH_FIELDS.get(type(obj), set())
    return {
        f.name: (str(v) if f.name in path_fields and v is not None else v)
        for f in fields(obj)
        for v in [getattr(obj, f.name)]
    }


def _sub_from_dict(cls, data: dict):
    path_fields = _PATH_FIELDS.get(cls, set())
    kwargs = {}
    for f in fields(cls):
        if f.name not in data:
            continue
        value = data[f.name]
        if f.name in path_fields and value is not None:
            value = Path(value)
        kwargs[f.name] = value
    return cls(**kwargs)


def config_to_dict(config: RunConfig) -> dict:
    return {
        "stage": _sub_to_dict(config.stage),
        "pixels": _sub_to_dict(config.pixels),
        "pi": _sub_to_dict(config.pi),
        "vna": _sub_to_dict(config.vna),
        "geometry": _sub_to_dict(config.geometry),
        "save": _sub_to_dict(config.save),
        "voltages_v": list(config.voltages_v),
        "return_home": config.return_home,
        "uniform_board_mode": config.uniform_board_mode,
        "dry_run": config.dry_run,
        "controller_type": config.controller_type,
        "uniform_board_settle_s": config.uniform_board_settle_s,
        "single_pixel_settle_s": config.single_pixel_settle_s,
        "uniform_board_settle_per_point": config.uniform_board_settle_per_point,
    }


def config_from_dict(data: dict) -> RunConfig:
    return RunConfig(
        stage=_sub_from_dict(StageConfig, data.get("stage", {})),
        pixels=_sub_from_dict(PixelControllerConfig, data.get("pixels", {})),
        pi=_sub_from_dict(PiControllerConfig, data.get("pi", {})),
        vna=_sub_from_dict(VNAConfig, data.get("vna", {})),
        geometry=_sub_from_dict(ScanGeometryConfig, data.get("geometry", {})),
        save=_sub_from_dict(SaveConfig, data.get("save", {})),
        voltages_v=tuple(data.get("voltages_v", (0.0,))),
        return_home=data.get("return_home", True),
        uniform_board_mode=data.get("uniform_board_mode", True),
        dry_run=data.get("dry_run", False),
        controller_type=data.get("controller_type", "pixel"),
        uniform_board_settle_s=data.get("uniform_board_settle_s", 0.5),
        single_pixel_settle_s=data.get("single_pixel_settle_s", 0.2),
        uniform_board_settle_per_point=data.get("uniform_board_settle_per_point", False),
    )


def save_config(config: RunConfig, path: str | Path) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(config_to_dict(config), f, indent=2)


def load_config(path: str | Path) -> RunConfig:
    with open(path, encoding="utf-8") as f:
        return config_from_dict(json.load(f))

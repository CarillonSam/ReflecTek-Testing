"""
Settings & Configuration tab: exposes only the fields that change run to run.
Hardware/connection/protocol-timing fields (COM ports, feed rate, timeouts, batch
sizes, Pi host info, etc.) stay in whatever RunConfig was loaded or defaulted to
(self._full_config) and are never shown here — set them in config.py or hand
operators a prepared preset via Load Settings.
"""

from __future__ import annotations

import tkinter as tk
from dataclasses import replace
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Callable

from config import RunConfig
from config_io import load_config, save_config


class ScrollableFrame(ttk.Frame):
    """A vertically scrollable frame. Put child widgets in .body."""

    def __init__(self, parent):
        super().__init__(parent)
        canvas = tk.Canvas(self, borderwidth=0, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        self.body = ttk.Frame(canvas)

        self.body.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.body, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _on_mousewheel))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))


class SettingsTab(ttk.Frame):
    """
    Tab 1: settings & configuration.
    get_config() layers the visible fields on top of self._full_config (dataclasses.replace),
    so hidden fields always come through unchanged. set_config(config) stores it as the new
    template and populates the visible widgets from it. Both are the integration points for
    the Scan tab and for presets.
    """

    def __init__(self, parent):
        super().__init__(parent)
        self.vars: dict[str, tk.Variable] = {}
        self.controller_type_var = tk.StringVar(value="pixel")
        self._full_config = RunConfig()

        # Called (no args) whenever a geometry field changes — the Scan tab's live
        # preview hooks into this. None until something wires it up (see gui_app.py).
        self.on_geometry_change: Callable[[], None] | None = None

        scroller = ScrollableFrame(self)
        scroller.pack(fill="both", expand=True)
        body = scroller.body

        self._build_general(body)
        self._build_stage(body)
        self._build_controller(body)
        self._build_vna(body)
        self._build_geometry(body)
        self._build_save(body)
        self._build_actions(body)

        self.set_config(self._full_config)

    # ---------------------------------------------------------------- widget helpers ----

    def _section(self, parent, title: str) -> ttk.LabelFrame:
        frame = ttk.LabelFrame(parent, text=title, padding=10)
        frame.pack(fill="x", padx=10, pady=6)
        return frame

    def _row(self, parent, row: int, label: str, key: str, kind: str = "str", browse: str | None = None,
              width: int = 24, on_change: Callable[[], None] | None = None):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=4, pady=3)
        if kind == "bool":
            var: tk.Variable = tk.BooleanVar(value=False)
            cb_kwargs = {"command": on_change} if on_change is not None else {}
            ttk.Checkbutton(parent, variable=var, **cb_kwargs).grid(row=row, column=1, sticky="w", padx=4, pady=3)
        else:
            var = tk.StringVar(value="")
            entry = ttk.Entry(parent, textvariable=var, width=width)
            entry.grid(row=row, column=1, sticky="w", padx=4, pady=3)
            if on_change is not None:
                entry.bind("<KeyRelease>", lambda e: on_change())
            if browse == "file":
                ttk.Button(parent, text="Browse...", command=lambda v=var: self._browse_file(v)).grid(row=row, column=2, padx=4)
            elif browse == "dir":
                ttk.Button(parent, text="Browse...", command=lambda v=var: self._browse_dir(v)).grid(row=row, column=2, padx=4)
        self.vars[key] = var

    @staticmethod
    def _browse_file(var: tk.StringVar) -> None:
        path = filedialog.askopenfilename()
        if path:
            var.set(path)

    @staticmethod
    def _browse_dir(var: tk.StringVar) -> None:
        path = filedialog.askdirectory()
        if path:
            var.set(path)

    # ---------------------------------------------------------------- sections ----

    def _build_general(self, parent) -> None:
        frame = self._section(parent, "General")
        r = 0
        ttk.Label(frame, text="Board controller").grid(row=r, column=0, sticky="w", padx=4, pady=3)
        combo = ttk.Combobox(frame, textvariable=self.controller_type_var, state="readonly",
                              values=["pixel", "pi"], width=21)
        combo.grid(row=r, column=1, sticky="w", padx=4, pady=3)
        combo.bind("<<ComboboxSelected>>", lambda e: self._on_controller_type_changed())
        r += 1
        self._row(frame, r, "Voltages (V), comma-separated", "voltages_v", width=40); r += 1
        self._row(frame, r, "Uniform board mode (one voltage, whole board)", "uniform_board_mode", "bool"); r += 1
        self._row(frame, r, "Re-send voltage every point (uniform mode only)", "uniform_board_settle_per_point", "bool"); r += 1
        self._row(frame, r, "Uniform-board settle time (s)", "uniform_board_settle_s"); r += 1
        self._row(frame, r, "Single-pixel settle time (s)", "single_pixel_settle_s"); r += 1
        self._row(frame, r, "Return stage home after scan", "return_home", "bool"); r += 1
        self._row(frame, r, "Dry run (no hardware; just log)", "dry_run", "bool"); r += 1

    def _build_stage(self, parent) -> None:
        frame = self._section(parent, "Motor Stage Calibration")
        self._row(frame, 0, "Calibration file", "stage_calibration_file", browse="file", width=32)
        ttk.Button(frame, text="Calibrate Stage...", command=self._on_calibrate).grid(
            row=1, column=0, columnspan=3, sticky="w", padx=4, pady=(6, 2)
        )

    def _on_calibrate(self) -> None:
        """
        Runs the interactive nudge-to-corner calibration (calibrate_stage.calibrate)
        against real hardware, synchronously on the GUI thread — this is a short,
        human-in-the-loop sequence (a handful of dialogs), not a long-running scan, so
        it doesn't need the background-thread treatment the Scan tab's actual scans do.
        Saves the result to whatever path is in the calibration-file field.
        """
        cal_path = self.vars["stage_calibration_file"].get().strip()
        if not cal_path:
            messagebox.showerror(
                "Calibration file required",
                "Enter a calibration file path first (e.g. stage_calibration.json) so the result has somewhere to save.",
            )
            return

        geometry = self.get_geometry_or_none()
        if geometry is None:
            messagebox.showerror(
                "Invalid geometry",
                "Fix the Scan Geometry fields first — calibration uses rows/cols/spacing to pick sensible corner points to nudge to.",
            )
            return

        if not messagebox.askyesno(
            "Calibrate stage",
            "This homes the stage and walks through the nudge-to-corner calibration "
            "protocol on the real hardware, with a dialog at each step. Continue?",
        ):
            return

        from calibrate_stage import calibrate
        from stage import GrblXY, HexGridPlanner

        stage_config = replace(self._full_config.stage, calibration_file=cal_path)
        try:
            stage = GrblXY(stage_config)
        except Exception as e:
            messagebox.showerror("Could not connect to stage", str(e))
            return

        try:
            planner = HexGridPlanner(geometry)
            # Signed, not just magnitude -- must match what HexGridPlanner computes for a
            # real scan point, or calibration ends up probing the mirror-image corner.
            x_span_mm = geometry.x_direction_sign * (geometry.cols - 1) * geometry.spacing_mm
            y_span_mm = geometry.y_direction_sign * (geometry.rows - 1) * planner.row_spacing_mm
            calibration = calibrate(stage, x_span_mm, y_span_mm, parent=self)
        except Exception as e:
            messagebox.showerror("Calibration failed", str(e))
            return
        finally:
            try:
                stage.goto_xy(0.0, 0.0)
            except Exception:
                pass
            stage.close()

        calibration.save(cal_path)
        self._full_config = replace(self._full_config, stage=stage_config)
        messagebox.showinfo("Calibration saved", f"Saved to {cal_path}:\n\n{calibration.to_dict()}")

    def _build_controller(self, parent) -> None:
        frame = self._section(parent, "Board Controller")

        self.pixel_frame = ttk.Frame(frame)
        self.pixel_frame.grid(row=0, column=0, sticky="ew")
        self._row(self.pixel_frame, 0, "L mapping CSV (optional)", "pixel_mapping_csv_l", browse="file", width=32)
        self._row(self.pixel_frame, 1, "H mapping CSV (optional)", "pixel_mapping_csv_h", browse="file", width=32)

        self.pi_frame = ttk.Frame(frame)
        self.pi_frame.grid(row=0, column=0, sticky="ew")
        ttk.Label(
            self.pi_frame,
            text="No mapping needed — the Pi has its own internal element-to-DAC map.\n"
                 "Whatever voltage grid is sent is uploaded directly, position for position.",
        ).grid(row=0, column=0, sticky="w", padx=4, pady=6)

        self._on_controller_type_changed()

    def _on_controller_type_changed(self) -> None:
        if self.controller_type_var.get() == "pi":
            self.pixel_frame.grid_remove()
            self.pi_frame.grid()
        else:
            self.pi_frame.grid_remove()
            self.pixel_frame.grid()

    def _build_vna(self, parent) -> None:
        frame = self._section(parent, "VNA")
        r = 0
        self._row(frame, r, "Start frequency (GHz)", "vna_start_ghz"); r += 1
        self._row(frame, r, "Stop frequency (GHz)", "vna_stop_ghz"); r += 1
        self._row(frame, r, "Number of points", "vna_points"); r += 1
        self._row(frame, r, "Dwell time before trigger (s)", "vna_dwell_s"); r += 1

    def _build_geometry(self, parent) -> None:
        frame = self._section(parent, "Scan Geometry (hex grid)")
        r = 0
        notify = self._notify_geometry_change
        self._row(frame, r, "Rows (of the L sub-grid)", "geo_rows", on_change=notify); r += 1
        self._row(frame, r, "Columns", "geo_cols", on_change=notify); r += 1
        self._row(frame, r, "Spacing (mm)", "geo_spacing_mm", on_change=notify); r += 1
        self._row(frame, r, "Row spacing override (mm, blank = auto hex)", "geo_row_spacing_mm", on_change=notify); r += 1
        self._row(frame, r, "Mirror stagger direction (flip which side offset rows overhang)", "geo_stagger_mirror", "bool", on_change=notify); r += 1

        ttk.Label(frame, text="Density to scan (L or H)").grid(row=r, column=0, sticky="w", padx=4, pady=3)
        self.density_mode_var = tk.StringVar(value="L")
        density_combo = ttk.Combobox(frame, textvariable=self.density_mode_var, state="readonly", values=["L", "H"], width=21)
        density_combo.grid(row=r, column=1, sticky="w", padx=4, pady=3)
        density_combo.bind("<<ComboboxSelected>>", lambda e: notify())
        r += 1

        ttk.Label(frame, text="L sub-grid (1, 2, or 3)").grid(row=r, column=0, sticky="w", padx=4, pady=3)
        self.l_subgrid_var = tk.StringVar(value="1")
        subgrid_combo = ttk.Combobox(frame, textvariable=self.l_subgrid_var, state="readonly", values=["1", "2", "3"], width=21)
        subgrid_combo.grid(row=r, column=1, sticky="w", padx=4, pady=3)
        subgrid_combo.bind("<<ComboboxSelected>>", lambda e: notify())
        r += 1

    def _notify_geometry_change(self) -> None:
        if self.on_geometry_change is not None:
            self.on_geometry_change()

    def get_geometry_or_none(self):
        """
        Parses the live-editable geometry fields (other ScanGeometryConfig fields come
        from self._full_config unchanged), for the Scan tab's preview. Returns None
        instead of raising if a field doesn't currently parse — e.g. mid-keystroke — so
        the preview just keeps showing the last valid geometry.
        """
        try:
            rows = int(self.vars["geo_rows"].get())
            cols = int(self.vars["geo_cols"].get())
            spacing_mm = float(self.vars["geo_spacing_mm"].get())
            row_spacing_raw = str(self.vars["geo_row_spacing_mm"].get()).strip()
            row_spacing_mm = float(row_spacing_raw) if row_spacing_raw else None
            l_subgrid = int(self.l_subgrid_var.get())
        except ValueError:
            return None
        stagger_sign = -1.0 if bool(self.vars["geo_stagger_mirror"].get()) else 1.0
        return replace(
            self._full_config.geometry,
            rows=rows, cols=cols, spacing_mm=spacing_mm, row_spacing_mm=row_spacing_mm,
            stagger_sign=stagger_sign, density_mode=self.density_mode_var.get(), l_subgrid=l_subgrid,
        )

    def _build_save(self, parent) -> None:
        frame = self._section(parent, "Save Output")
        r = 0
        self._row(frame, r, "Output directory", "save_output_dir", browse="dir", width=40); r += 1
        self._row(frame, r, "Run name", "save_run_name"); r += 1
        self._row(frame, r, "Save per-point .npz files", "save_save_individual_npz", "bool"); r += 1
        self._row(frame, r, "Save summary .npz file", "save_save_summary_npz", "bool"); r += 1
        self._row(frame, r, "Save metadata.json", "save_save_metadata_json", "bool"); r += 1

    def _build_actions(self, parent) -> None:
        frame = ttk.Frame(parent, padding=10)
        frame.pack(fill="x", padx=10, pady=10)
        ttk.Button(frame, text="Validate Settings", command=self._on_validate).pack(side="left", padx=4)
        ttk.Button(frame, text="Save Settings...", command=self._on_save).pack(side="left", padx=4)
        ttk.Button(frame, text="Load Settings...", command=self._on_load).pack(side="left", padx=4)
        ttk.Button(frame, text="Reset to Defaults", command=lambda: self.set_config(RunConfig())).pack(side="left", padx=4)

    # ---------------------------------------------------------------- actions ----

    def _on_validate(self) -> None:
        try:
            self.get_config()
        except ValueError as e:
            messagebox.showerror("Invalid settings", str(e))
            return
        messagebox.showinfo("Settings valid", "All settings look valid.")

    def _on_save(self) -> None:
        try:
            config = self.get_config()
        except ValueError as e:
            messagebox.showerror("Invalid settings", f"Fix these before saving:\n\n{e}")
            return
        path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON", "*.json")])
        if not path:
            return
        try:
            save_config(config, path)
        except OSError as e:
            messagebox.showerror("Save failed", str(e))
            return
        messagebox.showinfo("Saved", f"Settings saved to {path}")

    def _on_load(self) -> None:
        path = filedialog.askopenfilename(filetypes=[("JSON", "*.json")])
        if not path:
            return
        try:
            config = load_config(path)
        except (OSError, ValueError, KeyError, TypeError) as e:
            messagebox.showerror("Load failed", f"Could not load {path}:\n\n{e}")
            return
        self.set_config(config)
        messagebox.showinfo("Loaded", f"Settings loaded from {path}")

    # ---------------------------------------------------------------- config <-> form ----

    def get_full_config(self) -> RunConfig:
        """The raw stored template (self._full_config), unvalidated — for callers that
        need hardware connection details (e.g. the Debug tab) without being blocked by
        unrelated validation errors elsewhere in the form. Use get_config() instead when
        you need the fully validated, visible-fields-applied config (e.g. to run a scan)."""
        return self._full_config

    def get_config(self) -> RunConfig:
        """
        Builds a RunConfig by layering the visible fields on top of self._full_config —
        every hidden field (ports, timeouts, batch sizes, Pi host info, rig-orientation
        constants, ...) passes through unchanged from whatever was loaded or defaulted.
        Raises ValueError (listing every problem found, not just the first) if anything
        visible can't be parsed.
        """
        errors: list[str] = []
        base = self._full_config

        def s(key: str) -> str:
            return str(self.vars[key].get()).strip()

        def b(key: str) -> bool:
            return bool(self.vars[key].get())

        def i(key: str, label: str) -> int:
            try:
                return int(s(key))
            except ValueError:
                errors.append(f"{label}: '{s(key)}' is not a whole number")
                return 0

        def f(key: str, label: str) -> float:
            try:
                return float(s(key))
            except ValueError:
                errors.append(f"{label}: '{s(key)}' is not a number")
                return 0.0

        def f_opt(key: str, label: str) -> float | None:
            raw = s(key)
            if raw == "":
                return None
            try:
                return float(raw)
            except ValueError:
                errors.append(f"{label}: '{raw}' is not a number (leave blank for auto)")
                return None

        def path_opt(key: str) -> Path | None:
            raw = s(key)
            return Path(raw) if raw else None

        voltages_raw = s("voltages_v")
        try:
            voltages_v = tuple(float(v) for v in (part.strip() for part in voltages_raw.split(",")) if v != "")
            if not voltages_v:
                errors.append("Voltages: enter at least one value")
        except ValueError:
            errors.append(f"Voltages: '{voltages_raw}' isn't a valid comma-separated list of numbers")
            voltages_v = (0.0,)

        stage = replace(base.stage, calibration_file=path_opt("stage_calibration_file"))
        pixels = replace(
            base.pixels,
            mapping_csv_l=path_opt("pixel_mapping_csv_l"),
            mapping_csv_h=path_opt("pixel_mapping_csv_h"),
        )
        vna = replace(
            base.vna,
            start_hz=f("vna_start_ghz", "VNA start frequency") * 1e9,
            stop_hz=f("vna_stop_ghz", "VNA stop frequency") * 1e9,
            points=i("vna_points", "VNA points"),
            dwell_s=f("vna_dwell_s", "VNA dwell time"),
        )
        geometry = replace(
            base.geometry,
            rows=i("geo_rows", "Geometry rows"),
            cols=i("geo_cols", "Geometry cols"),
            spacing_mm=f("geo_spacing_mm", "Geometry spacing"),
            row_spacing_mm=f_opt("geo_row_spacing_mm", "Geometry row spacing override"),
            stagger_sign=-1.0 if b("geo_stagger_mirror") else 1.0,
            density_mode=self.density_mode_var.get(),
            l_subgrid=int(self.l_subgrid_var.get()),
        )

        output_dir_raw = s("save_output_dir")
        run_name_raw = s("save_run_name")
        if not output_dir_raw:
            errors.append("Save: output directory is required")
        if not run_name_raw:
            errors.append("Save: run name is required")
        save = replace(
            base.save,
            output_dir=Path(output_dir_raw or "."),
            run_name=run_name_raw,
            save_individual_npz=b("save_save_individual_npz"),
            save_summary_npz=b("save_save_summary_npz"),
            save_metadata_json=b("save_save_metadata_json"),
        )

        if errors:
            raise ValueError("\n".join(errors))

        return replace(
            base,
            stage=stage, pixels=pixels, pi=base.pi, vna=vna, geometry=geometry, save=save,
            voltages_v=voltages_v,
            return_home=b("return_home"),
            uniform_board_mode=b("uniform_board_mode"),
            dry_run=b("dry_run"),
            controller_type=self.controller_type_var.get(),
            uniform_board_settle_s=f("uniform_board_settle_s", "Uniform board settle time"),
            single_pixel_settle_s=f("single_pixel_settle_s", "Single pixel settle time"),
            uniform_board_settle_per_point=b("uniform_board_settle_per_point"),
        )

    def set_config(self, config: RunConfig) -> None:
        """Stores config as the new template and populates the visible widgets from it."""
        self._full_config = config

        def s(key: str, value) -> None:
            self.vars[key].set("" if value is None else str(value))

        def b(key: str, value) -> None:
            self.vars[key].set(bool(value))

        self.controller_type_var.set(config.controller_type)
        s("stage_calibration_file", config.stage.calibration_file)
        s("voltages_v", ", ".join(str(v) for v in config.voltages_v))
        b("uniform_board_mode", config.uniform_board_mode)
        b("uniform_board_settle_per_point", config.uniform_board_settle_per_point)
        s("uniform_board_settle_s", config.uniform_board_settle_s)
        s("single_pixel_settle_s", config.single_pixel_settle_s)
        b("return_home", config.return_home)
        b("dry_run", config.dry_run)

        s("pixel_mapping_csv_l", config.pixels.mapping_csv_l)
        s("pixel_mapping_csv_h", config.pixels.mapping_csv_h)

        s("vna_start_ghz", config.vna.start_hz / 1e9)
        s("vna_stop_ghz", config.vna.stop_hz / 1e9)
        s("vna_points", config.vna.points)
        s("vna_dwell_s", config.vna.dwell_s)

        s("geo_rows", config.geometry.rows)
        s("geo_cols", config.geometry.cols)
        s("geo_spacing_mm", config.geometry.spacing_mm)
        s("geo_row_spacing_mm", config.geometry.row_spacing_mm)
        b("geo_stagger_mirror", config.geometry.stagger_sign < 0)
        self.density_mode_var.set(config.geometry.density_mode)
        self.l_subgrid_var.set(str(config.geometry.l_subgrid))

        s("save_output_dir", config.save.output_dir)
        s("save_run_name", config.save.run_name)
        b("save_save_individual_npz", config.save.save_individual_npz)
        b("save_save_summary_npz", config.save.save_summary_npz)
        b("save_save_metadata_json", config.save.save_metadata_json)

        self._on_controller_type_changed()
        self._notify_geometry_change()
